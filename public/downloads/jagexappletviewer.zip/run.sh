#!/bin/sh
java -Djava.class.path=jagexappletviewer.jar -Dcom.jagex.config=http://www.04scaper.ca/java_config.ws -Xmx128m -Xss2m jagexappletviewer lostcity